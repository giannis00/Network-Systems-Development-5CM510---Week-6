import socket
import json
import threading
import time
import random
import sys

BROADCAST_PORT = 50000
BROADCAST_ADDR = '<broadcast>'
INTERVAL = 5

def make_message(msg_type, device, value=None, role='sensor'):
    data = {"type": msg_type, "device": device, "role": role, "timestamp": time.time()}
    if value is not None:
        data["value"] = value
    return json.dumps(data).encode('utf-8')

def broadcast_presence(device, role='sensor'):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    while True:
        sock.sendto(make_message("hello", device, role=role), (BROADCAST_ADDR, BROADCAST_PORT))
        if role == 'sensor':
            temp = round(random.uniform(20,30),1)
            sock.sendto(make_message("temperature", device, temp, role), (BROADCAST_ADDR, BROADCAST_PORT))
            print(f"[{device}] Broadcasted HELLO & temp {temp}°C")
        time.sleep(INTERVAL)

def listen_for_peers(device):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', BROADCAST_PORT))
    known_peers = set()
    while True:
        data, addr = sock.recvfrom(1024)
        try:
            msg = json.loads(data.decode('utf-8'))
            sender = msg.get("device")
            if sender != device:
                if sender not in known_peers:
                    known_peers.add(sender)
                    print(f"[{device}] Discovered new peer: {sender} @ {addr}")
                if msg["type"] == "temperature":
                    value = msg["value"]
                    print(f"[{device}] Received temperature from {sender}: {value}°C")
                    if "actuator" in device.lower():
                        if value > 25:
                            print(f"[{device}] Action: Fan ON")
                        else:
                            print(f"[{device}] Action: Fan OFF")
        except json.JSONDecodeError:
            pass

def main():
    if len(sys.argv) < 2:
        print("Usage: python peer.py <device_name> [role]")
        sys.exit(1)
    device = sys.argv[1]
    role = sys.argv[2] if len(sys.argv)>2 else 'sensor'
    listener = threading.Thread(target=listen_for_peers, args=(device,), daemon=True)
    listener.start()
    broadcast_presence(device, role=role)

if __name__ == "__main__":
    main()
