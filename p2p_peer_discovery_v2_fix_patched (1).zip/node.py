
import argparse
import socket
from typing import Dict, Tuple
from peer_to_peer.network import Network
from peer_to_peer.discovery import DiscoveryService
from peer_to_peer.peer_registry import PeerRegistry
from peer_to_peer.connection import Connection

STATE: Dict[str, str] = {}  # simple key-value
network = None
registry = None

def handle_message(msg: dict, conn: Connection):
    global network
    t = msg.get("type")
    if t == "echo":
        conn.send({"type": "echo_reply", "data": msg.get("data")})
    elif t == "kv_put":
        k, v = msg.get("key"), msg.get("value")
        if isinstance(k, str):
            STATE[k] = str(v)
            if network:
                network.broadcast({"type": "kv_gossip", "key": k, "value": STATE[k]})
            conn.send({"type": "ok"})
    elif t == "kv_gossip":
        k, v = msg.get("key"), msg.get("value")
        if isinstance(k, str):
            STATE[k] = str(v)
    elif t == "kv_get":
        k = msg.get("key")
        conn.send({"type": "kv_get_reply", "key": k, "value": STATE.get(k)})
    elif t == "who":
        peers = [f"{h}:{p}" for (h,p) in network.peers()] if network else []
        conn.send({"type": "peers", "peers": peers})

def repl():
    print("Commands: echo <text> | put <k> <v> | get <k> | peers | quit")
    while True:
        try:
            line = input("> ").strip()
        except EOFError:
            break
        if not line:
            continue
        if line == "quit":
            break
        parts = line.split()
        cmd = parts[0]
        if cmd == "echo" and len(parts) >= 2:
            msg = {"type":"echo", "data":" ".join(parts[1:])}
            if network:
                network.broadcast(msg)
        elif cmd == "put" and len(parts) >= 3:
            k = parts[1]; v = " ".join(parts[2:])
            STATE[k] = v
            if network:
                network.broadcast({"type":"kv_gossip","key":k,"value":v})
            print("OK")
        elif cmd == "get" and len(parts) == 2:
            k = parts[1]
            print(STATE.get(k))
        elif cmd == "peers":
            if registry:
                infos = registry.list()
                if not infos:
                    print("(no peers)")
                else:
                    for info in infos:
                        print(f"{info.host}:{info.port}  status={info.status}  last_attempt={int(info.last_attempt) if info.last_attempt else 0}  successes={info.success_count}  fails={info.fail_count}")
            else:
                print("(no registry)")
        else:
            print("Unknown command")
    print("Bye")

def on_peer_discovered(peer: Tuple[str,int]):
    host, port = peer
    if network:
        if (host, port) not in network.peers():
            ok = network.connect(host, port)
            if ok:
                print(f"Connected to {host}:{port}")

def main():
    global network, registry
    parser = argparse.ArgumentParser(description="Simple P2P node with LAN discovery")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=50001)
    parser.add_argument("--name", default=socket.gethostname())
    parser.add_argument("--bootstrap", nargs="*", default=[], help="Host:port of peers to connect to initially")
    args = parser.parse_args()

    registry = PeerRegistry()
    network = Network(args.host, args.port, handle_message, registry=registry)
    network.start()
    print(f"Listening on {args.host}:{args.port}")

    disc = DiscoveryService(args.name, args.port, on_peer_discovered)
    disc.start()

    for item in args.bootstrap:
        host, p = item.split(":")
        if network.connect(host, int(p)):
            print(f"Connected to {host}:{p}")

    try:
        repl()
    finally:
        disc.stop()
        network.stop()

if __name__ == "__main__":
    main()
