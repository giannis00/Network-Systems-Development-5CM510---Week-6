
import socket
import threading
from typing import Dict, Tuple, Callable, Optional, List
from .peer_registry import PeerRegistry
from .connection import Connection

class Network:
    def __init__(self, host: str, port: int, on_message: Callable[[dict, Connection], None], registry: Optional[PeerRegistry] = None):
        self.host = host
        self.port = int(port)
        self.on_message = on_message
        self.listener: Optional[socket.socket] = None
        self.accept_thread: Optional[threading.Thread] = None
        self.connections: Dict[Tuple[str, int], Connection] = {}
        self.lock = threading.Lock()
        self.running = False
        self.registry = registry

    def start(self):
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind((self.host, self.port))
        self.listener.listen()
        self.running = True
        self.accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.accept_thread.start()

    def _accept_loop(self):
        while self.running:
            try:
                sock, addr = self.listener.accept()
                self._wrap_connection(sock, addr)
            except OSError:
                break

    def _wrap_connection(self, sock, addr):
        conn = Connection(sock, addr, self.on_message, self._on_close)
        with self.lock:
            self.connections[(addr[0], addr[1])] = conn
        if self.registry:
            try:
                self.registry.record_incoming_connected(addr[0], int(addr[1]))
            except Exception:
                pass
        conn.start()

    def connect(self, host: str, port: int, timeout: float = 2.5) -> bool:
        success = False
        try:
            sock = socket.create_connection((host, int(port)), timeout=timeout)
            self._wrap_connection(sock, (host, int(port)))
            success = True
            return True
        except OSError:
            success = False
            return False
        finally:
            if self.registry:
                try:
                    self.registry.record_attempt(host, int(port), success)
                except Exception:
                    pass

    def broadcast(self, message: dict):
        with self.lock:
            targets = list(self.connections.values())
        for c in targets:
            try:
                c.send(message)
            except Exception:
                pass

    def peers(self) -> List[Tuple[str, int]]:
        with self.lock:
            return list(self.connections.keys())

    def _on_close(self, conn: Connection):
        with self.lock:
            for key, value in list(self.connections.items()):
                if value is conn:
                    del self.connections[key]
                    host, port = key
                    if self.registry:
                        try:
                            self.registry.record_disconnected(host, int(port))
                        except Exception:
                            pass
                    break

    def stop(self):
        self.running = False
        try:
            if self.listener:
                self.listener.close()
        except Exception:
            pass
        with self.lock:
            conns = list(self.connections.values())
        for c in conns:
            c.close()
