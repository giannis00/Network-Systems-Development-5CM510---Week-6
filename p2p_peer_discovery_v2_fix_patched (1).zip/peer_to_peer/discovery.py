
import json
import socket
import struct
import threading
import time
import uuid
from typing import Callable, Dict, Tuple

MCAST_GRP = '239.255.0.1'
MCAST_PORT = 41000
BEACON_INTERVAL = 60.0  # seconds

class DiscoveryService:
    """Simple UDP multicast LAN discovery.
    Each node broadcasts (id, tcp_port) every 60s. Listeners notify on new peers.
    """
    def __init__(self, name: str, tcp_port: int, on_peer: Callable[[Tuple[str,int]], None]):
        self.name = name
        self.tcp_port = int(tcp_port)
        self.node_id = str(uuid.uuid4())
        self.on_peer = on_peer
        self.running = False
        self.recv_thread = None
        self.send_thread = None
        self.seen: Dict[Tuple[str,int], float] = {}

    def start(self):
        self.running = True
        self.recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self.send_thread = threading.Thread(target=self._send_loop, daemon=True)
        self.recv_thread.start()
        self.send_thread.start()

    def _send_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        ttl = struct.pack('b', 1)  # local network only
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)
        payload = {
            "type": "p2p_discovery",
            "name": self.name,
            "id": self.node_id,
            "port": self.tcp_port,
        }
        while self.running:
            try:
                sock.sendto(json.dumps(payload).encode('utf-8'), (MCAST_GRP, MCAST_PORT))
            except Exception:
                pass
            time.sleep(BEACON_INTERVAL)

    def _recv_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(('', MCAST_PORT))
        except OSError:
            pass
        mreq = struct.pack('4sl', socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        while self.running:
            try:
                data, (ip, _) = sock.recvfrom(65535)
                msg = json.loads(data.decode('utf-8'))
                if msg.get("type") != "p2p_discovery":
                    continue
                if ip.startswith("127."):
                    continue
                key = (ip, int(msg.get("port", 0)))
                self.seen[key] = time.time()
                self.on_peer(key)
            except Exception:
                pass

    def stop(self):
        self.running = False
