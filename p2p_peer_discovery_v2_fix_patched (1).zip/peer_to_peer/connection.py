
import json
import socket
import struct
import threading
from typing import Callable, Optional

HEADER_LEN = 4  # 4-byte big-endian length prefix

def pack_message(obj: dict) -> bytes:
    payload = json.dumps(obj).encode("utf-8")
    return struct.pack("!I", len(payload)) + payload

def recv_exact(sock: socket.socket, n: int) -> bytes:
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("socket closed")
        buf += chunk
    return buf

def recv_message(sock: socket.socket) -> dict:
    (length,) = struct.unpack("!I", recv_exact(sock, HEADER_LEN))
    data = recv_exact(sock, length)
    return json.loads(data.decode("utf-8"))

class Connection:
    def __init__(self, sock: socket.socket, addr, on_message: Callable[[dict, 'Connection'], None], on_close: Callable[['Connection'], None]):
        self.sock = sock
        self.addr = addr
        self.on_message = on_message
        self.on_close = on_close
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self.lock = threading.Lock()

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        try:
            while self.running:
                msg = recv_message(self.sock)
                self.on_message(msg, self)
        except Exception:
            pass
        finally:
            self.running = False
            try:
                self.sock.close()
            finally:
                self.on_close(self)

    def send(self, obj: dict):
        data = pack_message(obj)
        with self.lock:
            self.sock.sendall(data)

    def close(self):
        self.running = False
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass
