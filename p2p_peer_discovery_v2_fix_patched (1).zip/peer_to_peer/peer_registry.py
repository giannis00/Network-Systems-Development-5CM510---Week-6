
import threading
import time
from dataclasses import dataclass
from typing import Dict, Tuple, List

@dataclass
class PeerInfo:
    host: str
    port: int
    status: str = "attempted"  # attempted | connected | disconnected
    last_attempt: float = 0.0
    connected_at: float = 0.0
    success_count: int = 0
    fail_count: int = 0

class PeerRegistry:
    def __init__(self):
        self._lock = threading.Lock()
        self._peers: Dict[Tuple[str, int], PeerInfo] = {}

    def _get(self, host: str, port: int) -> PeerInfo:
        key = (host, int(port))
        if key not in self._peers:
            self._peers[key] = PeerInfo(host=host, port=int(port))
        return self._peers[key]

    def record_attempt(self, host: str, port: int, success: bool):
        now = time.time()
        with self._lock:
            info = self._get(host, port)
            info.last_attempt = now
            if success:
                info.status = "connected"
                info.connected_at = now
                info.success_count += 1
            else:
                if info.status != "connected":
                    info.status = "attempted"
                info.fail_count += 1

    def record_incoming_connected(self, host: str, port: int):
        now = time.time()
        with self._lock:
            info = self._get(host, port)
            info.status = "connected"
            info.connected_at = now
            info.success_count += 1

    def record_disconnected(self, host: str, port: int):
        with self._lock:
            info = self._get(host, port)
            info.status = "disconnected"

    def list(self) -> List[PeerInfo]:
        """Return peers that have *actually* been attempted/connected.
        Only include peers whose last_attempt > 0 (i.e., we tried to reach them at least once).
        """
        with self._lock:
            return [p for p in self._peers.values() if getattr(p, "last_attempt", 0) and p.last_attempt > 0]

    def list_all(self) -> List[PeerInfo]:
        """Return all known peers (including ones never attempted)."""
        with self._lock:
            return list(self._peers.values())
