
# Lab: Simple Peer-to-Peer (with 60s Peer Discovery & Registry)

Follow README quick start. Use `peers` to view the registry and watch it update as discovery triggers connection attempts every 60 seconds.

Tips:
- If you want more aggressive retries, just run `peers` occasionally and/or add a periodic retry in `on_peer_discovered`.
- Firewalls: allow inbound TCP on your port and UDP 41000.
