
# Simple P2P with 60s LAN Discovery (Python)

- **Peer discovery every 60 seconds** (multicast 239.255.0.1:41000)
- **Echo** demo
- **Distributed key-value (best-effort gossip)**
- **Peer registry** tracking attempts and connections

## Quick start

```bash
python node.py --port 50001
python node.py --port 50002 --bootstrap 127.0.0.1:50001
```

Then in either console:
```
> put hello world
> get hello
world
> peers
# shows status per peer with counters
```

---

## Revamp highlights

- Discovery beacons now every **60 seconds**.
- Registry records **every connection attempt**, plus incoming accepts and disconnects.
- `peers` shows `attempted|connected|disconnected`, last attempt, and counters.
