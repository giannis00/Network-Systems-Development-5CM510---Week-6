#!/usr/bin/env python3
"""        Simple script to inject a search into the network.
Usage:
  python search_client.py --port 9001 --query charlie --ttl 2
"""
import argparse
import asyncio
import json
import uuid
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
HOST = '127.0.0.1'

async def send_search(port: int, query: str, ttl: int):
    msg = {
        'type': 'search',
        'id': str(uuid.uuid4()),
        'query': query,
        'ttl': int(ttl),
        'origin': [HOST, port],
    }
    try:
        reader, writer = await asyncio.open_connection(HOST, port)
        writer.write((json.dumps(msg) + '\n').encode())
        await writer.drain()
        logging.info(f"Sent search {msg['id']} -> port {port} query='{query}' ttl={ttl}")
        writer.close()
        await writer.wait_closed()
    except Exception as e:
        logging.error(f"Failed to send search to port {port}: {e}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--query', type=str, required=True)
    parser.add_argument('--ttl', type=int, default=2)
    args = parser.parse_args()
    asyncio.run(send_search(args.port, args.query, args.ttl))
