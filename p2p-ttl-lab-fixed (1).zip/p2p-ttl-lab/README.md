# P2P TTL Search Lab

This repository implements a simple TCP-based P2P network in Python that demonstrates how **TTL** controls search propagation.

## Overview
- Each node is an independent process that listens on a TCP port and connects to configured peers.
- Search messages carry a `ttl` integer. Each time a node forwards a search, it decrements `ttl`.
- If `ttl` reaches 0, nodes do not forward the search further.
- Nodes track seen `msg_id`s to avoid re-forwarding the same search (prevents loops).

## Files
- `node.py` — The node server implementation.
- `search_client.py` — A small client to issue search requests into the network.
- `run_nodes.sh` — Convenience script to launch 3 nodes (Linux/macOS).
- `examples/nodeN_files.txt` — Lists of filenames each node "hosts" (used for search hits).

## Requirements
- Python 3.9+
- `asyncio` (standard library), `aiofiles` not required. No external packages required.

Install (optional):
```
python -m pip install -r requirements.txt
```

## Quickstart (lab)
1. Unzip the package.
2. Start three nodes (see `run_nodes.sh`) or run nodes manually:
   - `python node.py --port 9001 --peers 9002,9003 --files examples/node1_files.txt`
   - `python node.py --port 9002 --peers 9001,9003 --files examples/node2_files.txt`
   - `python node.py --port 9003 --peers 9001,9002 --files examples/node3_files.txt`
3. From a separate terminal, issue a search:
   - `python search_client.py --port 9001 --query alpha --ttl 1`
   - `python search_client.py --port 9001 --query bravo --ttl 2`
   - `python search_client.py --port 9001 --query charlie --ttl 3`

Observe how TTL affects which nodes receive the query and whether a match is found.

## How TTL works in this codebase
- When `search_client.py` sends a search with `ttl=1` to node `9001`, node `9001` will process the query and if it doesn't have the file it will _not_ forward it because forwarding would decrement TTL to 0.
- With `ttl=2`, the search can be forwarded one hop (so nodes 9002/9003 can be reached depending on topology).
- A `ttl=3` will let it travel two hops, etc.

## Example expected behavior (with provided example files)
- `node1_files.txt` contains: `alpha`.
- `node2_files.txt` contains: `bravo`.
- `node3_files.txt` contains: `charlie`.

- Searching for `alpha` from node 9002 with `ttl=1` will find `alpha` if 9002 is directly connected to 9001.
- Searching for `charlie` from node 9001 with `ttl=2` will reach node 9003 and return a hit.

---

## Lab exercises (suggested)

1. Start the three nodes with the provided `run_nodes.sh`.
2. From a separate terminal, send a search for `alpha` to node 9002 with `ttl=1`:
   - `python search_client.py --port 9002 --query alpha --ttl 1`
   - Observe: node 9002 will not forward because TTL=1; but if node2 also had `alpha` it would reply locally.
3. Send the same search with `ttl=2`:
   - `python search_client.py --port 9002 --query alpha --ttl 2`
   - Observe: it should be forwarded to node 9001, which has `alpha`, and node1 will send a `result` back to the origin.
4. Try `python search_client.py --port 9001 --query charlie --ttl 2`:
   - Should reach node 9003 and get a result.
5. Try reducing TTL to verify limited propagation.

---

## Notes & Extensions
- This is intentionally minimal to keep the lab focused on TTL and message routing.
- Extensions: add UDP transport, routing tables, hop counts, more realistic NAT traversal, or a GUI visualizer.

---

Enjoy the lab!
