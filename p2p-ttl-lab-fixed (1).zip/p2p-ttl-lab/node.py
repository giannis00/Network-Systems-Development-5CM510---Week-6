#!/usr/bin/env python3
"""        Simple asyncio TCP P2P node that supports search with TTL.
Run: python node.py --port 9001 --peers 9002,9003 --files examples/node1_files.txt
"""
import argparse
import asyncio
import json
import logging
import uuid
from typing import Set, Tuple

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

HOST = '127.0.0.1'

class P2PNode:
    def __init__(self, port: int, peers: Set[int], files: Set[str]):
        self.port = port
        self.peers = peers
        self.files = files
        self.seen_msgs = set()  # track message IDs to prevent loops

    async def start(self):
        server = await asyncio.start_server(self.handle_conn, HOST, self.port)
        addr = server.sockets[0].getsockname()
        logging.info(f"Node listening on {addr}")
        async with server:
            await server.serve_forever()

    async def handle_conn(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        peer = writer.get_extra_info('peername')
        data = await reader.readline()
        if not data:
            writer.close()
            await writer.wait_closed()
            return
        try:
            msg = json.loads(data.decode())
        except Exception as e:
            logging.warning(f"Failed to decode message from {peer}: {e}")
            writer.close()
            await writer.wait_closed()
            return

        mtype = msg.get('type')
        if mtype == 'search':
            await self.handle_search(msg, peer)
        elif mtype == 'result':
            logging.info(f"[port {self.port}] Received result for query '{msg.get('query')}' -> {msg.get('holder')} (from {peer})")
        else:
            logging.warning(f"Unknown message type: {mtype} from {peer}")

        writer.close()
        await writer.wait_closed()

    async def handle_search(self, msg, peer):
        msg_id = msg.get('id')
        query = msg.get('query')
        ttl = int(msg.get('ttl', 0))
        origin = tuple(msg.get('origin')) if isinstance(msg.get('origin'), list) else tuple(msg.get('origin'))
        sender = tuple(peer[:2]) if peer else None

        if msg_id in self.seen_msgs:
            logging.debug(f"[port {self.port}] Already seen msg {msg_id}; ignoring")
            return
        self.seen_msgs.add(msg_id)

        logging.info(f"[port {self.port}] SEARCH id={msg_id} query='{query}' ttl={ttl} origin={origin} sender={sender}")

        # If we have the file, reply directly to origin
        if query in self.files:
            logging.info(f"[port {self.port}] I have '{query}' — sending result to origin {origin}")
            await self.send_result(query, origin)
            # We *can* still forward if ttl>1 (design choice). Here we forward only if ttl>1.

        # Forwarding logic: decrement ttl and forward if ttl > 1
        if ttl > 1:
            new_msg = dict(msg)
            new_msg['ttl'] = ttl - 1
            # forward to all peers except the node we got the message from
            await self.forward_to_peers(new_msg, exclude_peer=peer)
        else:
            logging.debug(f"[port {self.port}] TTL too low ({ttl}); not forwarding")

    async def send_result(self, query: str, origin: Tuple[str, int]):
        host, port = origin
        try:
            reader, writer = await asyncio.open_connection(host, port)
            result = {
                'type': 'result',
                'query': query,
                'holder': ['127.0.0.1', self.port],
            }
            writer.write((json.dumps(result) + '\n').encode())
            await writer.drain()
            writer.close()
            await writer.wait_closed()
            logging.info(f"[port {self.port}] Sent result for '{query}' to {origin}")
        except Exception as e:
            logging.warning(f"[port {self.port}] Failed to send result to {origin}: {e}")

    async def forward_to_peers(self, msg, exclude_peer=None):
        to_send = json.dumps(msg) + '\n'
        for peer_port in self.peers:
            try:
                # skip if exclude_peer matches this peer
                if exclude_peer:
                    ep = exclude_peer
                    try:
                        ep_port = ep[1]
                    except Exception:
                        ep_port = None
                    if ep_port == peer_port:
                        continue
                logging.debug(f"[port {self.port}] Forwarding to {peer_port}: {msg}")
                reader, writer = await asyncio.open_connection(HOST, peer_port)
                writer.write(to_send.encode())
                await writer.drain()
                writer.close()
                await writer.wait_closed()
            except Exception as e:
                logging.warning(f"[port {self.port}] Could not forward to {peer_port}: {e}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run a simple P2P node')
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--peers', type=str, default='')
    parser.add_argument('--files', type=str, default='')
    args = parser.parse_args()

    peers = set()
    if args.peers:
        for p in args.peers.split(','):
            if p.strip():
                peers.add(int(p.strip()))

    files = set()
    if args.files:
        try:
            with open(args.files, 'r') as f:
                for l in f:
                    l = l.strip()
                    if l:
                        files.add(l)
        except FileNotFoundError:
            logging.warning(f"Files list {args.files} not found; starting with empty file set")

    node = P2PNode(args.port, peers, files)
    try:
        asyncio.run(node.start())
    except KeyboardInterrupt:
        logging.info('Node shutting down')
