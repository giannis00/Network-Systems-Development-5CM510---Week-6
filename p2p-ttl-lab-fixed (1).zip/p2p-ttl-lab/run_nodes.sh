#!/usr/bin/env bash
# Launch three nodes for local testing. Make executable (chmod +x run_nodes.sh)
python node.py --port 9001 --peers 9002,9003 --files examples/node1_files.txt &
python node.py --port 9002 --peers 9001,9003 --files examples/node2_files.txt &
python node.py --port 9003 --peers 9001,9002 --files examples/node3_files.txt &

echo "Nodes started (pids):"
ps -f | grep node.py | grep -v grep

# To stop them: kill <pid>
